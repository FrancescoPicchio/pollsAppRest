Django REST API app for creating polls, and submitting and retrieving answers to said polls.

Before running this locally create a .env for each the back-end and front-end, each of them exactly in the parent folder back-end and front-end.
    In the front-end you need to initialize CLIENT_URL to the localhost where you host the react app.
    In the back-end you need to initialize REST_API_URL to the localhost where you host the django rest api.