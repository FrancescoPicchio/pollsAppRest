import React from 'react';

const Profile = () => {
  return (
    <div>
      <h2>Profile</h2>
      <p>This is the profile page.</p>
    </div>
  );
};

export default Profile;